import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import AmbulanceTracker from './components/AmbulanceTracker';
import PatientManagement from './components/PatientManagement';
import AITriage from './components/AITriage';
import Equipment from './components/Equipment';
import Analytics from './components/Analytics';
import Emergencies from './components/Emergencies';
import AIAssistant from './components/AIAssistant';
import LiveMap from './components/LiveMap';
import Header from './components/Header';

function App() {
  const [activeModule, setActiveModule] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [realTimeData, setRealTimeData] = useState({
    bedAvailability: 45,
    icuAvailability: 12,
    ambulancesActive: 8,
    emergenciesQueue: 3,
    staffOnDuty: 127
  });

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeData(prev => ({
        bedAvailability: Math.max(0, prev.bedAvailability + Math.floor(Math.random() * 3) - 1),
        icuAvailability: Math.max(0, prev.icuAvailability + Math.floor(Math.random() * 2) - 1),
        ambulancesActive: Math.max(0, prev.ambulancesActive + Math.floor(Math.random() * 2) - 1),
        emergenciesQueue: Math.max(0, prev.emergenciesQueue + Math.floor(Math.random() * 2) - 1),
        staffOnDuty: Math.max(100, prev.staffOnDuty + Math.floor(Math.random() * 5) - 2)
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const renderModule = () => {
    switch (activeModule) {
      case 'dashboard':
        return <Dashboard realTimeData={realTimeData} />;
      case 'ambulance':
        return <AmbulanceTracker />;
      case 'patients':
        return <PatientManagement />;
      case 'triage':
        return <AITriage />;
      case 'equipment':
        return <Equipment />;
      case 'analytics':
        return <Analytics />;
      case 'emergencies':
        return <Emergencies />;
      case 'assistant':
        return <AIAssistant />;
      case 'map':
        return <LiveMap />;
      default:
        return <Dashboard realTimeData={realTimeData} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar 
        activeModule={activeModule} 
        setActiveModule={setActiveModule}
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
      />
      <div className={`flex-1 flex flex-col transition-all duration-300 ${
        sidebarCollapsed ? 'ml-16' : 'ml-64'
      }`}>
        <Header 
          activeModule={activeModule}
          toggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)}
          realTimeData={realTimeData}
        />
        <main className="flex-1 p-6 overflow-y-auto">
          {renderModule()}
        </main>
      </div>
    </div>
  );
}

export default App;