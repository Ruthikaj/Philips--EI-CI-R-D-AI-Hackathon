import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Clock, 
  Users, 
  Download,
  RefreshCw,
  Calendar,
  Filter,
  Zap
} from 'lucide-react';

const Analytics: React.FC = () => {
  const [timeRange, setTimeRange] = useState('24h');
  const [liveData, setLiveData] = useState({
    triageStats: { critical: 12, moderate: 34, mild: 67 },
    equipmentUsage: { operational: 87, maintenance: 8, faulty: 5 },
    staffPerformance: { excellent: 45, good: 78, average: 23 },
    waitTimes: { current: 23, average: 28, target: 15 }
  });

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveData(prev => ({
        triageStats: {
          critical: Math.max(0, prev.triageStats.critical + Math.floor(Math.random() * 3) - 1),
          moderate: Math.max(0, prev.triageStats.moderate + Math.floor(Math.random() * 5) - 2),
          mild: Math.max(0, prev.triageStats.mild + Math.floor(Math.random() * 7) - 3)
        },
        equipmentUsage: {
          operational: Math.min(100, Math.max(70, prev.equipmentUsage.operational + Math.floor(Math.random() * 3) - 1)),
          maintenance: Math.min(30, Math.max(0, prev.equipmentUsage.maintenance + Math.floor(Math.random() * 2) - 1)),
          faulty: Math.min(20, Math.max(0, prev.equipmentUsage.faulty + Math.floor(Math.random() * 2) - 1))
        },
        staffPerformance: prev.staffPerformance,
        waitTimes: {
          current: Math.max(5, prev.waitTimes.current + Math.floor(Math.random() * 6) - 3),
          average: prev.waitTimes.average,
          target: 15
        }
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const generateMockChartData = (points: number) => {
    return Array.from({ length: points }, (_, i) => ({
      time: `${String(Math.floor(i * 24 / points)).padStart(2, '0')}:00`,
      value: Math.floor(Math.random() * 100) + 20
    }));
  };

  const chartData = generateMockChartData(12);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <BarChart3 className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Real-Time Analytics</h2>
              <p className="text-sm text-gray-500">Live data streams and AI insights</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            >
              <option value="1h">Last Hour</option>
              <option value="24h">Last 24 Hours</option>
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days</option>
            </select>
            <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Download className="w-4 h-4" />
              <span>Export</span>
            </button>
          </div>
        </div>

        {/* Live Status Indicator */}
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-600">Live data streaming</span>
          <RefreshCw className="w-4 h-4 text-gray-400 animate-spin" />
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-600">Avg Wait Time</h3>
            <Clock className="w-4 h-4 text-gray-400" />
          </div>
          <div className="flex items-end space-x-2">
            <span className="text-3xl font-bold text-gray-900">{liveData.waitTimes.current}</span>
            <span className="text-sm text-gray-500 mb-1">minutes</span>
          </div>
          <div className="flex items-center mt-2">
            <div className={`w-full h-2 bg-gray-200 rounded-full overflow-hidden`}>
              <div 
                className={`h-full transition-all duration-500 ${
                  liveData.waitTimes.current <= liveData.waitTimes.target ? 'bg-green-500' : 'bg-red-500'
                }`}
                style={{ width: `${(liveData.waitTimes.current / 60) * 100}%` }}
              />
            </div>
            <span className="ml-2 text-xs text-gray-500">
              Target: {liveData.waitTimes.target}m
            </span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-600">Triage Queue</h3>
            <Users className="w-4 h-4 text-gray-400" />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-red-600">Critical</span>
              <span className="text-lg font-bold text-red-600">{liveData.triageStats.critical}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-yellow-600">Moderate</span>
              <span className="text-lg font-bold text-yellow-600">{liveData.triageStats.moderate}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-green-600">Mild</span>
              <span className="text-lg font-bold text-green-600">{liveData.triageStats.mild}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-600">Equipment Status</h3>
            <TrendingUp className="w-4 h-4 text-gray-400" />
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Operational</span>
              <div className="flex items-center space-x-2">
                <div className="w-16 h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-green-500 rounded-full transition-all duration-500"
                    style={{ width: `${liveData.equipmentUsage.operational}%` }}
                  />
                </div>
                <span className="text-sm font-medium text-green-600">
                  {liveData.equipmentUsage.operational}%
                </span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Maintenance</span>
              <div className="flex items-center space-x-2">
                <div className="w-16 h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-yellow-500 rounded-full transition-all duration-500"
                    style={{ width: `${liveData.equipmentUsage.maintenance * 10}%` }}
                  />
                </div>
                <span className="text-sm font-medium text-yellow-600">
                  {liveData.equipmentUsage.maintenance}%
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-600">System Efficiency</h3>
            <Zap className="w-4 h-4 text-gray-400" />
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-blue-600 mb-2">92%</div>
            <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
              <div className="bg-blue-500 h-2 rounded-full" style={{ width: '92%' }}></div>
            </div>
            <p className="text-xs text-gray-500">Overall system performance</p>
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Patient Inflow Chart */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Patient Inflow Trends</h3>
            <button className="text-sm text-blue-600 hover:text-blue-700">View Details</button>
          </div>
          <div className="h-64 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-4 flex items-end justify-between">
            {chartData.map((point, index) => (
              <div key={index} className="flex flex-col items-center space-y-2">
                <div
                  className="w-6 bg-blue-500 rounded-t-sm transition-all duration-500 hover:bg-blue-600"
                  style={{ height: `${point.value}%` }}
                />
                <span className="text-xs text-gray-500 transform -rotate-45">
                  {point.time}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-center justify-between text-sm text-gray-600">
            <span>Peak: 2:00 PM - 4:00 PM</span>
            <span className="flex items-center space-x-1">
              <TrendingUp className="w-4 h-4 text-green-500" />
              <span className="text-green-600">+12% from yesterday</span>
            </span>
          </div>
        </div>

        {/* Staff Performance */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Staff Performance</h3>
            <button className="text-sm text-blue-600 hover:text-blue-700">Detailed Report</button>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 font-semibold text-sm">A</span>
                </div>
                <div>
                  <p className="font-medium text-gray-900">Dr. Sarah Chen</p>
                  <p className="text-sm text-gray-500">Emergency Medicine</p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center space-x-2">
                  <div className="w-16 h-2 bg-gray-200 rounded-full">
                    <div className="w-14 h-2 bg-green-500 rounded-full"></div>
                  </div>
                  <span className="text-sm font-medium text-green-600">95%</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">24 patients today</p>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-semibold text-sm">B</span>
                </div>
                <div>
                  <p className="font-medium text-gray-900">Dr. Michael Rodriguez</p>
                  <p className="text-sm text-gray-500">Internal Medicine</p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center space-x-2">
                  <div className="w-16 h-2 bg-gray-200 rounded-full">
                    <div className="w-12 h-2 bg-blue-500 rounded-full"></div>
                  </div>
                  <span className="text-sm font-medium text-blue-600">88%</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">19 patients today</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <span className="text-purple-600 font-semibold text-sm">C</span>
                </div>
                <div>
                  <p className="font-medium text-gray-900">Dr. Emily Johnson</p>
                  <p className="text-sm text-gray-500">Cardiology</p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center space-x-2">
                  <div className="w-16 h-2 bg-gray-200 rounded-full">
                    <div className="w-15 h-2 bg-purple-500 rounded-full"></div>
                  </div>
                  <span className="text-sm font-medium text-purple-600">92%</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">16 patients today</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Insights Panel */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-2 bg-yellow-100 rounded-lg">
            <Zap className="w-5 h-5 text-yellow-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900">AI Insights & Predictions</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-semibold text-blue-900 mb-2">Shift Optimization</h4>
            <p className="text-sm text-blue-700 mb-2">
              Increase staff by 15% during 2-6 PM peak hours
            </p>
            <div className="flex items-center text-xs text-blue-600">
              <TrendingUp className="w-3 h-3 mr-1" />
              <span>Potential 23% wait time reduction</span>
            </div>
          </div>
          
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h4 className="font-semibold text-green-900 mb-2">Equipment Prediction</h4>
            <p className="text-sm text-green-700 mb-2">
              Ventilator VNT-003 requires maintenance in 3 days
            </p>
            <div className="flex items-center text-xs text-green-600">
              <Clock className="w-3 h-3 mr-1" />
              <span>Schedule before critical threshold</span>
            </div>
          </div>
          
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <h4 className="font-semibold text-orange-900 mb-2">Capacity Alert</h4>
            <p className="text-sm text-orange-700 mb-2">
              ICU will reach 95% capacity by 8 PM today
            </p>
            <div className="flex items-center text-xs text-orange-600">
              <Users className="w-3 h-3 mr-1" />
              <span>Consider patient transfers</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;