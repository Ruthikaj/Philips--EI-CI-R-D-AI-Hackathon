import React, { useState } from 'react';
import { 
  Mic, 
  Send, 
  AlertTriangle, 
  Brain, 
  Truck, 
  Phone,
  FileText,
  Clock,
  User,
  Activity,
  Heart
} from 'lucide-react';

interface TriageResult {
  urgency: 'critical' | 'moderate' | 'mild';
  conditions: string[];
  suggestedTests: string[];
  confidence: number;
  estimatedWaitTime: string;
}

const AITriage: React.FC = () => {
  const [symptoms, setSymptoms] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [triageResult, setTriageResult] = useState<TriageResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [patientInfo, setPatientInfo] = useState({
    age: '',
    gender: '',
    medicalHistory: ''
  });

  const handleVoiceInput = () => {
    setIsListening(!isListening);
    // Simulate voice input
    if (!isListening) {
      setTimeout(() => {
        setSymptoms(prev => prev + (prev ? '. ' : '') + 'Patient complains of chest pain and shortness of breath');
        setIsListening(false);
      }, 2000);
    }
  };

  const handleSubmitTriage = async () => {
    if (!symptoms.trim()) return;
    
    setIsProcessing(true);
    
    // Simulate AI processing
    setTimeout(() => {
      const mockResult: TriageResult = {
        urgency: symptoms.toLowerCase().includes('chest pain') ? 'critical' : 
                symptoms.toLowerCase().includes('fever') ? 'moderate' : 'mild',
        conditions: symptoms.toLowerCase().includes('chest pain') ? 
                   ['Acute Coronary Syndrome', 'Pulmonary Embolism', 'Anxiety Attack'] :
                   ['Upper Respiratory Infection', 'Viral Syndrome', 'Allergic Reaction'],
        suggestedTests: symptoms.toLowerCase().includes('chest pain') ?
                       ['ECG', 'Chest X-Ray', 'Cardiac Enzymes', 'D-Dimer'] :
                       ['Complete Blood Count', 'Vital Signs', 'Throat Swab'],
        confidence: 87,
        estimatedWaitTime: symptoms.toLowerCase().includes('chest pain') ? 'Immediate' : '45 minutes'
      };
      
      setTriageResult(mockResult);
      setIsProcessing(false);
    }, 3000);
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical': return 'bg-red-500 text-white';
      case 'moderate': return 'bg-yellow-500 text-white';
      case 'mild': return 'bg-green-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const handleEmergencyActions = () => {
    // Simulate emergency protocol activation
    alert('🚨 Emergency Protocol Activated!\n\n✓ Ambulance dispatched\n✓ Emergency staff notified\n✓ ICU bed reserved');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-2 bg-purple-100 rounded-lg">
            <Brain className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-900">AI-Powered Triage System</h2>
            <p className="text-sm text-gray-500">Intelligent symptom analysis and priority assessment</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Patient Assessment</h3>
          
          {/* Patient Basic Info */}
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Age</label>
              <input
                type="number"
                value={patientInfo.age}
                onChange={(e) => setPatientInfo(prev => ({ ...prev, age: e.target.value }))}
                placeholder="Age"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
              <select
                value={patientInfo.gender}
                onChange={(e) => setPatientInfo(prev => ({ ...prev, gender: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              >
                <option value="">Select</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
              <div className="flex items-center h-10">
                {triageResult && (
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getUrgencyColor(triageResult.urgency)}`}>
                    {triageResult.urgency}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Symptoms Input */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Symptoms Description
            </label>
            <div className="relative">
              <textarea
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
                placeholder="Describe the patient's symptoms, pain level, duration, and any relevant details..."
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none"
              />
              <button
                onClick={handleVoiceInput}
                className={`absolute bottom-3 right-3 p-2 rounded-lg transition-all ${
                  isListening 
                    ? 'bg-red-500 text-white animate-pulse' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Mic className="w-4 h-4" />
              </button>
            </div>
            {isListening && (
              <p className="text-sm text-red-600 mt-2 flex items-center">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-2"></div>
                Listening... Speak now
              </p>
            )}
          </div>

          {/* Medical History */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Medical History (Optional)
            </label>
            <input
              type="text"
              value={patientInfo.medicalHistory}
              onChange={(e) => setPatientInfo(prev => ({ ...prev, medicalHistory: e.target.value }))}
              placeholder="Known conditions, allergies, medications..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            />
          </div>

          <button
            onClick={handleSubmitTriage}
            disabled={!symptoms.trim() || isProcessing}
            className={`w-full flex items-center justify-center space-x-2 px-4 py-3 rounded-lg transition-all ${
              !symptoms.trim() || isProcessing
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            {isProcessing ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Analyzing with AI...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Analyze Symptoms</span>
              </>
            )}
          </button>
        </div>

        {/* Results Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Triage Results</h3>
          
          {triageResult ? (
            <div className="space-y-6">
              {/* Urgency Level */}
              <div className="text-center">
                <div className={`inline-flex items-center space-x-2 px-6 py-3 rounded-full text-lg font-semibold ${getUrgencyColor(triageResult.urgency)}`}>
                  <AlertTriangle className="w-5 h-5" />
                  <span>{triageResult.urgency.toUpperCase()}</span>
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  AI Confidence: {triageResult.confidence}%
                </p>
              </div>

              {/* Likely Conditions */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <Activity className="w-4 h-4 mr-2 text-blue-600" />
                  Likely Conditions
                </h4>
                <div className="space-y-2">
                  {triageResult.conditions.map((condition, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="text-sm font-medium text-gray-900">{condition}</span>
                      <span className="text-xs text-gray-500">
                        {index === 0 ? 'Most Likely' : index === 1 ? 'Possible' : 'Consider'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Suggested Tests */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <FileText className="w-4 h-4 mr-2 text-green-600" />
                  Recommended Tests
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  {triageResult.suggestedTests.map((test, index) => (
                    <div key={index} className="px-3 py-2 bg-green-50 text-green-700 rounded-lg text-sm font-medium text-center">
                      {test}
                    </div>
                  ))}
                </div>
              </div>

              {/* Wait Time */}
              <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-blue-900">Estimated Wait Time</span>
                </div>
                <span className="text-blue-700 font-bold">{triageResult.estimatedWaitTime}</span>
              </div>

              {/* Emergency Actions */}
              {triageResult.urgency === 'critical' && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-3">
                    <AlertTriangle className="w-5 h-5 text-red-600" />
                    <h4 className="font-semibold text-red-900">Emergency Protocol Required</h4>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={handleEmergencyActions}
                      className="flex items-center justify-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                    >
                      <Truck className="w-4 h-4" />
                      <span>Dispatch Ambulance</span>
                    </button>
                    <button className="flex items-center justify-center space-x-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
                      <Phone className="w-4 h-4" />
                      <span>Alert Staff</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Auto-push to EHR */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <FileText className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-medium text-green-900">Auto-sync to EHR</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-sm text-green-700">Synchronized</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <Brain className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Enter symptoms to get AI-powered triage assessment</p>
              <p className="text-sm text-gray-400 mt-2">
                System uses advanced ML models for accurate medical analysis
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AITriage;