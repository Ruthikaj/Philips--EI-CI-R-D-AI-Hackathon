import React, { useState } from 'react';
import { 
  User, 
  FileText, 
  Upload, 
  Camera, 
  Search,
  Edit3,
  Heart,
  Activity,
  Calendar,
  Phone,
  Mail,
  MapPin,
  Eye
} from 'lucide-react';

interface Patient {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female';
  aadhaar: string;
  phone: string;
  email: string;
  address: string;
  bloodGroup: string;
  conditions: string[];
  lastVisit: string;
  status: 'active' | 'discharged' | 'critical';
  verified: boolean;
}

const PatientManagement: React.FC = () => {
  const [patients] = useState<Patient[]>([
    {
      id: 'P-2024-001',
      name: 'Rajesh Kumar',
      age: 45,
      gender: 'male',
      aadhaar: '****-****-1234',
      phone: '+91 98765 43210',
      email: 'rajesh@email.com',
      address: '123 MG Road, Mumbai',
      bloodGroup: 'O+',
      conditions: ['Diabetes', 'Hypertension'],
      lastVisit: '2024-01-15',
      status: 'active',
      verified: true
    },
    {
      id: 'P-2024-002',
      name: 'Priya Sharma',
      age: 32,
      gender: 'female',
      aadhaar: '****-****-5678',
      phone: '+91 87654 32109',
      email: 'priya@email.com',
      address: '456 Park Avenue, Delhi',
      bloodGroup: 'A+',
      conditions: ['Asthma'],
      lastVisit: '2024-01-14',
      status: 'critical',
      verified: true
    },
    {
      id: 'P-2024-003',
      name: 'Mohammed Ali',
      age: 28,
      gender: 'male',
      aadhaar: '****-****-9012',
      phone: '+91 76543 21098',
      email: 'ali@email.com',
      address: '789 Gandhi Street, Bangalore',
      bloodGroup: 'B-',
      conditions: [],
      lastVisit: '2024-01-13',
      status: 'discharged',
      verified: false
    }
  ]);

  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showCameraModal, setShowCameraModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPatients = patients.filter(patient =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700';
      case 'critical': return 'bg-red-100 text-red-700';
      case 'discharged': return 'bg-gray-100 text-gray-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Patient Management</h2>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            Add New Patient
          </button>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by name or patient ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            />
          </div>
          <button 
            className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            onClick={() => setShowUploadModal(true)}
          >
            <Upload className="w-4 h-4" />
            <span>Upload Reports</span>
          </button>
          <button 
            className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            onClick={() => setShowCameraModal(true)}
          >
            <Camera className="w-4 h-4" />
            <span>Face Auth</span>
          </button>
        </div>
      </div>

      {/* Patient List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-900">Patients ({filteredPatients.length})</h3>
          <div className="space-y-3">
            {filteredPatients.map((patient) => (
              <div 
                key={patient.id}
                className={`bg-white rounded-lg shadow-sm border p-4 cursor-pointer transition-all duration-200 hover:shadow-md ${
                  selectedPatient?.id === patient.id ? 'border-blue-500 ring-1 ring-blue-500' : 'border-gray-200'
                }`}
                onClick={() => setSelectedPatient(patient)}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{patient.name}</h4>
                      <p className="text-sm text-gray-500">{patient.id}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {patient.verified && (
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    )}
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(patient.status)}`}>
                      {patient.status}
                    </span>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">Age: {patient.age}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Heart className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">{patient.bloodGroup}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Phone className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">{patient.phone}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Activity className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">{patient.lastVisit}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Patient Details */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          {selectedPatient ? (
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Patient Details</h3>
                <button className="flex items-center space-x-2 px-3 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                  <Edit3 className="w-4 h-4" />
                  <span>Edit</span>
                </button>
              </div>
              
              <div className="space-y-6">
                {/* Personal Information */}
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Personal Information</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-500">Full Name</label>
                      <p className="mt-1 text-gray-900">{selectedPatient.name}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-500">Patient ID</label>
                      <p className="mt-1 text-gray-900">{selectedPatient.id}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-500">Age</label>
                      <p className="mt-1 text-gray-900">{selectedPatient.age} years</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-500">Gender</label>
                      <p className="mt-1 text-gray-900 capitalize">{selectedPatient.gender}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-500">Blood Group</label>
                      <p className="mt-1 text-gray-900">{selectedPatient.bloodGroup}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-500">Aadhaar</label>
                      <p className="mt-1 text-gray-900">{selectedPatient.aadhaar}</p>
                    </div>
                  </div>
                </div>

                {/* Contact Information */}
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Contact Information</h4>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <Phone className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-900">{selectedPatient.phone}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Mail className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-900">{selectedPatient.email}</span>
                    </div>
                    <div className="flex items-start space-x-3">
                      <MapPin className="w-4 h-4 text-gray-400 mt-0.5" />
                      <span className="text-gray-900">{selectedPatient.address}</span>
                    </div>
                  </div>
                </div>

                {/* Medical Conditions */}
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Medical Conditions</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedPatient.conditions.length > 0 ? (
                      selectedPatient.conditions.map((condition, index) => (
                        <span 
                          key={index}
                          className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm"
                        >
                          {condition}
                        </span>
                      ))
                    ) : (
                      <span className="text-gray-500 text-sm">No known conditions</span>
                    )}
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="grid grid-cols-2 gap-3 pt-4 border-t border-gray-100">
                  <button className="flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                    <FileText className="w-4 h-4" />
                    <span>View Reports</span>
                  </button>
                  <button className="flex items-center justify-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                    <Eye className="w-4 h-4" />
                    <span>Medical History</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-6 text-center text-gray-500">
              <User className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p>Select a patient to view details</p>
            </div>
          )}
        </div>
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-lg max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Upload Medical Reports</h3>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-sm text-gray-600 mb-2">
                Drag & drop files here or click to browse
              </p>
              <p className="text-xs text-gray-500">
                Supports: PDF, JPG, PNG, DICOM
              </p>
              <p className="text-xs text-gray-500 mt-2">
                AI will extract data using OCR & image analysis
              </p>
            </div>
            <div className="flex space-x-3 mt-6">
              <button
                onClick={() => setShowUploadModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Upload
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Camera Modal */}
      {showCameraModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-lg max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Face Authentication</h3>
            <div className="bg-gray-100 h-48 rounded-lg flex items-center justify-center mb-4">
              <div className="text-center">
                <Camera className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Camera preview</p>
                <p className="text-xs text-gray-500">Using TensorFlow + FaceAPI.js</p>
              </div>
            </div>
            <div className="flex space-x-3">
              <button
                onClick={() => setShowCameraModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                Authenticate
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientManagement;