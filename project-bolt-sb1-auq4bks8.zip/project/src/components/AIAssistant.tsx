import React, { useState, useRef, useEffect } from 'react';
import { 
  MessageSquare, 
  Send, 
  Mic, 
  Upload, 
  User, 
  Bot,
  Calendar,
  FileText,
  Truck,
  Bed,
  Languages,
  Phone
} from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  language?: 'en' | 'hi' | 'ta';
}

const AIAssistant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: 'Hello! I\'m your AI healthcare assistant. I can help you with:\n\n• Booking appointments\n• Uploading medical reports\n• Tracking ambulances\n• Checking bed availability\n• Medical queries (20+ FAQs)\n\nHow can I assist you today?',
      timestamp: new Date(),
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<'en' | 'hi' | 'ta'>('en');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickActions = [
    { icon: Calendar, text: 'Book Appointment', query: 'book appointment' },
    { icon: FileText, text: 'Upload Report', query: 'upload my report' },
    { icon: Truck, text: 'Track Ambulance', query: 'track ambulance' },
    { icon: Bed, text: 'Check ICU', query: 'show ICU availability' },
  ];

  const faqs = [
    { question: 'How do I book an appointment?', answer: 'You can book an appointment by providing your preferred date, time, and department. I\'ll check availability and confirm your slot.' },
    { question: 'What are the visiting hours?', answer: 'General visiting hours are 10 AM to 8 PM. ICU visiting hours are 11 AM to 1 PM and 4 PM to 6 PM.' },
    { question: 'How can I get my test results?', answer: 'Test results are available online through our patient portal or you can collect physical copies from the lab after 24-48 hours.' },
    { question: 'What should I bring for admission?', answer: 'Please bring valid ID, insurance cards, list of current medications, and any relevant medical records.' },
  ];

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date(),
      language: selectedLanguage
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate AI processing
    setTimeout(() => {
      const botResponse = generateBotResponse(inputMessage);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: botResponse,
        timestamp: new Date(),
        language: selectedLanguage
      };
      
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const generateBotResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();

    // Appointment booking
    if (lowerQuery.includes('book') && lowerQuery.includes('appointment')) {
      return 'I can help you book an appointment! Please provide:\n\n1. Preferred date and time\n2. Department (General, Cardiology, etc.)\n3. Type of consultation\n\nExample: "Book appointment for cardiology on Jan 20th at 2 PM"';
    }

    // Upload report
    if (lowerQuery.includes('upload') && lowerQuery.includes('report')) {
      return '📄 To upload your medical report:\n\n1. Click the upload button below\n2. Select your file (PDF, JPG, PNG supported)\n3. I\'ll use AI to extract and summarize the data\n4. The report will be added to your medical record\n\nWould you like me to guide you through the upload process?';
    }

    // Ambulance tracking
    if (lowerQuery.includes('track') && lowerQuery.includes('ambulance')) {
      return '🚑 Ambulance Status:\n\n• AMB-001: En route to your location (ETA: 8 mins)\n• AMB-002: At hospital (available)\n• AMB-003: Responding to emergency\n\nWould you like live GPS tracking for a specific ambulance?';
    }

    // ICU availability
    if (lowerQuery.includes('icu') || lowerQuery.includes('bed')) {
      return '🛏️ Current Bed Availability:\n\n• General Beds: 45 available\n• ICU Beds: 12 available\n• Emergency Beds: 8 available\n• Private Rooms: 23 available\n\nWould you like to reserve a bed or see availability at nearby hospitals?';
    }

    // Medical queries
    const matchingFAQ = faqs.find(faq => 
      faq.question.toLowerCase().includes(lowerQuery) || 
      lowerQuery.includes(faq.question.toLowerCase().split(' ').slice(0, 3).join(' '))
    );
    
    if (matchingFAQ) {
      return `💡 ${matchingFAQ.answer}\n\nIs there anything else you'd like to know about this topic?`;
    }

    // Visiting hours
    if (lowerQuery.includes('visiting') || lowerQuery.includes('hours')) {
      return '🕐 Hospital Visiting Hours:\n\n• General Wards: 10 AM - 8 PM\n• ICU: 11 AM - 1 PM, 4 PM - 6 PM\n• Emergency: 24/7 (limited access)\n• Pediatric: 9 AM - 9 PM\n\nPlease carry valid ID for entry.';
    }

    // Emergency
    if (lowerQuery.includes('emergency') || lowerQuery.includes('urgent')) {
      return '🚨 For medical emergencies:\n\n• Call emergency hotline: +91-911\n• Visit Emergency Department (24/7)\n• Use our emergency app for immediate assistance\n\nIs this a current emergency? I can connect you to emergency services immediately.';
    }

    // Default response with language support
    const responses = {
      en: 'I understand you\'re asking about healthcare services. Could you be more specific? I can help with:\n\n• Appointments & scheduling\n• Medical reports & results\n• Hospital services & information\n• Emergency assistance\n• Insurance & billing\n\nTry asking: "Book appointment", "Upload report", or "Emergency help"',
      hi: 'मैं समझ गया कि आप स्वास्थ्य सेवाओं के बारे में पूछ रहे हैं। कृपया अधिक स्पष्ट रूप से बताएं। मैं इनमें मदद कर सकता हूं:\n\n• अपॉइंटमेंट बुकिंग\n• मेडिकल रिपोर्ट\n• अस्पताल की सेवाएं\n• आपातकालीन सहायता',
      ta: 'நீங்கள் சுகாதார சேவைகளைப் பற்றி கேட்கிறீர்கள் என்பதை நான் புரிந்துகொள்கிறேன். இவற்றில் நான் உதவ முடியும்:\n\n• அப்பாய்ன்ட்மென்ட் பதிவு\n• மருத்துவ அறிக்கைகள்\n• மருத்துவமனை சேவைகள்\n• அவசர உதவி'
    };

    return responses[selectedLanguage];
  };

  const handleVoiceInput = () => {
    setIsListening(!isListening);
    // Simulate voice input
    if (!isListening) {
      setTimeout(() => {
        setInputMessage('I need to book an appointment for cardiology');
        setIsListening(false);
      }, 2000);
    }
  };

  const handleQuickAction = (query: string) => {
    setInputMessage(query);
  };

  const handleFileUpload = () => {
    // Simulate file upload and AI processing
    const uploadMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: '📄 Uploaded: Blood_Test_Report_Jan2024.pdf',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, uploadMessage]);

    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: '🤖 AI Analysis Complete!\n\n📊 **Report Summary:**\n• Blood Sugar: 98 mg/dl (Normal)\n• Cholesterol: 185 mg/dl (Borderline)\n• Hemoglobin: 13.2 g/dl (Normal)\n• WBC Count: 7,200 (Normal)\n\n✅ Overall: Results within normal range except cholesterol\n💡 Recommendation: Consider diet modification\n\nReport has been added to your medical record. Would you like to schedule a follow-up with your doctor?',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 2000);
  };

  const handleEscalation = () => {
    const escalationMessage: Message = {
      id: Date.now().toString(),
      type: 'bot',
      content: '👨‍⚕️ I\'m connecting you with a human assistant...\n\nEstimated wait time: 2-3 minutes\n\nWhile you wait, you can:\n• Continue asking me questions\n• Browse our FAQ section\n• Use the voice feature for hands-free interaction\n\nA healthcare professional will be with you shortly.',
      timestamp: new Date()
    };
    setMessages(prev => [...prev, escalationMessage]);
  };

  return (
    <div className="h-full flex flex-col space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <MessageSquare className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">AI Healthcare Assistant</h2>
              <p className="text-sm text-gray-500">Multilingual support • Voice enabled • 24/7 available</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value as 'en' | 'hi' | 'ta')}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
            >
              <option value="en">🇺🇸 English</option>
              <option value="hi">🇮🇳 हिंदी</option>
              <option value="ta">🇮🇳 தமிழ்</option>
            </select>
            <button
              onClick={handleEscalation}
              className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span>Human Help</span>
            </button>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <button
                key={index}
                onClick={() => handleQuickAction(action.query)}
                className="flex items-center space-x-2 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-left"
              >
                <Icon className="w-4 h-4 text-purple-600" />
                <span className="text-sm font-medium text-gray-900">{action.text}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Chat Interface */}
      <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col">
        {/* Messages */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4 max-h-96">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex items-start space-x-3 max-w-xs lg:max-w-md ${
                message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
              }`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  message.type === 'user' ? 'bg-blue-100' : 'bg-purple-100'
                }`}>
                  {message.type === 'user' ? (
                    <User className="w-4 h-4 text-blue-600" />
                  ) : (
                    <Bot className="w-4 h-4 text-purple-600" />
                  )}
                </div>
                <div className={`px-4 py-2 rounded-lg whitespace-pre-line ${
                  message.type === 'user' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-900'
                }`}>
                  <p className="text-sm">{message.content}</p>
                  <p className={`text-xs mt-1 ${
                    message.type === 'user' ? 'text-blue-200' : 'text-gray-500'
                  }`}>
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <Bot className="w-4 h-4 text-purple-600" />
                </div>
                <div className="bg-gray-100 px-4 py-2 rounded-lg">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="border-t border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <button
              onClick={handleFileUpload}
              className="p-2 text-gray-400 hover:text-purple-600 transition-colors"
            >
              <Upload className="w-5 h-5" />
            </button>
            <button
              onClick={handleVoiceInput}
              className={`p-2 transition-colors ${
                isListening 
                  ? 'text-red-500 animate-pulse' 
                  : 'text-gray-400 hover:text-purple-600'
              }`}
            >
              <Mic className="w-5 h-5" />
            </button>
            <div className="flex-1 relative">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder={
                  selectedLanguage === 'hi' ? 'अपना प्रश्न टाइप करें...' :
                  selectedLanguage === 'ta' ? 'உங்கள் கேள்வியை தட்டச்சு செய்க...' :
                  'Type your question...'
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
              />
              {isListening && (
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                </div>
              )}
            </div>
            <button
              onClick={handleSendMessage}
              disabled={!inputMessage.trim()}
              className={`p-2 rounded-lg transition-colors ${
                inputMessage.trim()
                  ? 'bg-purple-600 text-white hover:bg-purple-700'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          
          {isListening && (
            <div className="mt-2 flex items-center justify-center space-x-2 text-sm text-red-600">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              <span>Listening... Speak now</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIAssistant;