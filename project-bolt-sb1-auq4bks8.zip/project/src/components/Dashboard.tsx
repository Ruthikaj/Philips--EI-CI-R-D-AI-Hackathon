import React, { useEffect, useState } from 'react';
import { 
  Activity, 
  Heart, 
  Users, 
  Truck, 
  Bed, 
  AlertTriangle,
  TrendingUp,
  Clock,
  MapPin,
  Zap
} from 'lucide-react';

interface DashboardProps {
  realTimeData: {
    bedAvailability: number;
    icuAvailability: number;
    ambulancesActive: number;
    emergenciesQueue: number;
    staffOnDuty: number;
  };
}

const Dashboard: React.FC<DashboardProps> = ({ realTimeData }) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [patientInflow, setPatientInflow] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setPatientInflow(prev => Math.max(0, prev + Math.floor(Math.random() * 3) - 1));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const kpiCards = [
    {
      title: 'Available Beds',
      value: realTimeData.bedAvailability,
      icon: Bed,
      color: 'green',
      trend: '+2',
      subtitle: 'Last updated now'
    },
    {
      title: 'ICU Capacity',
      value: realTimeData.icuAvailability,
      icon: Heart,
      color: 'red',
      trend: '-1',
      subtitle: '78% occupied'
    },
    {
      title: 'Active Ambulances',
      value: realTimeData.ambulancesActive,
      icon: Truck,
      color: 'blue',
      trend: '+1',
      subtitle: '3 en route'
    },
    {
      title: 'Emergency Queue',
      value: realTimeData.emergenciesQueue,
      icon: AlertTriangle,
      color: 'orange',
      trend: '0',
      subtitle: 'Avg wait: 12 min'
    },
    {
      title: 'Staff on Duty',
      value: realTimeData.staffOnDuty,
      icon: Users,
      color: 'purple',
      trend: '+5',
      subtitle: 'Next shift: 6 AM'
    },
    {
      title: 'Patient Inflow',
      value: patientInflow,
      icon: TrendingUp,
      color: 'indigo',
      trend: '+3',
      subtitle: 'Today so far'
    }
  ];

  const recentActivities = [
    { time: '2 min ago', action: 'New patient admitted to ICU-3', status: 'critical' },
    { time: '5 min ago', action: 'Ambulance EMS-007 dispatched', status: 'active' },
    { time: '8 min ago', action: 'CT scan completed for Patient #1234', status: 'completed' },
    { time: '12 min ago', action: 'Blood test results uploaded', status: 'completed' },
    { time: '15 min ago', action: 'Emergency alert resolved', status: 'resolved' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'critical': return 'text-red-600 bg-red-50';
      case 'active': return 'text-blue-600 bg-blue-50';
      case 'completed': return 'text-green-600 bg-green-50';
      case 'resolved': return 'text-gray-600 bg-gray-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {kpiCards.map((card, index) => {
          const Icon = card.icon;
          const colorClasses = {
            green: 'bg-green-500 text-white',
            red: 'bg-red-500 text-white',
            blue: 'bg-blue-500 text-white',
            orange: 'bg-orange-500 text-white',
            purple: 'bg-purple-500 text-white',
            indigo: 'bg-indigo-500 text-white'
          };
          
          return (
            <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{card.title}</p>
                  <p className="text-3xl font-bold text-gray-900 mb-2">{card.value}</p>
                  <div className="flex items-center space-x-2">
                    <span className={`text-sm px-2 py-1 rounded-full ${
                      parseInt(card.trend) > 0 ? 'bg-green-100 text-green-600' : 
                      parseInt(card.trend) < 0 ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-600'
                    }`}>
                      {card.trend}
                    </span>
                    <span className="text-sm text-gray-500">{card.subtitle}</span>
                  </div>
                </div>
                <div className={`p-3 rounded-lg ${colorClasses[card.color as keyof typeof colorClasses]}`}>
                  <Icon className="w-6 h-6" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Real-time Activity Feed */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-6 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Real-time Activity</h3>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-gray-500">Live</span>
              </div>
            </div>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {recentActivities.map((activity, index) => (
                <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">{activity.action}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <Clock className="w-3 h-3 text-gray-400" />
                      <span className="text-xs text-gray-500">{activity.time}</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(activity.status)}`}>
                        {activity.status}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Actions & AI Insights */}
        <div className="space-y-6">
          {/* AI Forecast */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Zap className="w-5 h-5 text-yellow-500 mr-2" />
              AI Insights
            </h3>
            <div className="space-y-3">
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-sm font-medium text-blue-900">Predicted Surge</p>
                <p className="text-xs text-blue-700 mt-1">+15% patient inflow expected between 2-4 PM</p>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <p className="text-sm font-medium text-green-900">Optimal Staffing</p>
                <p className="text-xs text-green-700 mt-1">Current staff levels are adequate for next 6 hours</p>
              </div>
              <div className="p-3 bg-orange-50 rounded-lg">
                <p className="text-sm font-medium text-orange-900">Equipment Alert</p>
                <p className="text-xs text-orange-700 mt-1">Ventilator maintenance due in 2 days</p>
              </div>
            </div>
          </div>

          {/* System Status */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">System Status</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Server Health</span>
                <div className="flex items-center space-x-2">
                  <div className="w-20 h-2 bg-gray-200 rounded-full">
                    <div className="w-16 h-2 bg-green-500 rounded-full"></div>
                  </div>
                  <span className="text-sm text-green-600 font-medium">98%</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Database</span>
                <div className="flex items-center space-x-2">
                  <div className="w-20 h-2 bg-gray-200 rounded-full">
                    <div className="w-18 h-2 bg-green-500 rounded-full"></div>
                  </div>
                  <span className="text-sm text-green-600 font-medium">95%</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">API Response</span>
                <div className="flex items-center space-x-2">
                  <div className="w-20 h-2 bg-gray-200 rounded-full">
                    <div className="w-14 h-2 bg-yellow-500 rounded-full"></div>
                  </div>
                  <span className="text-sm text-yellow-600 font-medium">87%</span>
                </div>
              </div>
            </div>
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-600">
                Last updated: {currentTime.toLocaleTimeString()}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;