import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Phone, 
  Clock, 
  Navigation, 
  AlertCircle,
  CheckCircle,
  Truck,
  User,
  Camera
} from 'lucide-react';

interface Ambulance {
  id: string;
  driverName: string;
  status: 'idle' | 'in-transit' | 'assigned';
  location: { lat: number; lng: number; address: string };
  eta: string;
  patientId?: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  verified: boolean;
}

const AmbulanceTracker: React.FC = () => {
  const [ambulances, setAmbulances] = useState<Ambulance[]>([
    {
      id: 'AMB-001',
      driverName: 'John Smith',
      status: 'in-transit',
      location: { lat: 40.7128, lng: -74.0060, address: '123 Main St, NYC' },
      eta: '8 minutes',
      patientId: 'P-2024-001',
      priority: 'critical',
      verified: true
    },
    {
      id: 'AMB-002',
      driverName: 'Maria Garcia',
      status: 'assigned',
      location: { lat: 40.7589, lng: -73.9851, address: '456 Broadway, NYC' },
      eta: '15 minutes',
      patientId: 'P-2024-002',
      priority: 'high',
      verified: true
    },
    {
      id: 'AMB-003',
      driverName: 'David Wilson',
      status: 'idle',
      location: { lat: 40.7831, lng: -73.9712, address: 'Central Hospital' },
      eta: '-',
      priority: 'low',
      verified: false
    }
  ]);

  const [selectedAmbulance, setSelectedAmbulance] = useState<string | null>(null);
  const [showVerificationModal, setShowVerificationModal] = useState(false);

  useEffect(() => {
    // Simulate real-time location updates
    const interval = setInterval(() => {
      setAmbulances(prev => prev.map(amb => ({
        ...amb,
        location: {
          ...amb.location,
          lat: amb.location.lat + (Math.random() - 0.5) * 0.001,
          lng: amb.location.lng + (Math.random() - 0.5) * 0.001
        }
      })));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'idle': return 'bg-gray-100 text-gray-700';
      case 'assigned': return 'bg-blue-100 text-blue-700';
      case 'in-transit': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-orange-600';
      case 'critical': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const handleVerifyDriver = (ambulanceId: string) => {
    setAmbulances(prev => prev.map(amb => 
      amb.id === ambulanceId ? { ...amb, verified: true } : amb
    ));
    setShowVerificationModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Live Ambulance Tracking</h2>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-600">GPS Active</span>
            </div>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              Dispatch New
            </button>
          </div>
        </div>
        
        {/* Map Placeholder */}
        <div className="bg-gradient-to-br from-blue-50 to-green-50 h-64 rounded-lg flex items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <svg className="w-full h-full" viewBox="0 0 400 200">
              <defs>
                <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#60a5fa" strokeWidth="0.5"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>
          <div className="text-center z-10">
            <MapPin className="w-12 h-12 text-blue-600 mx-auto mb-2" />
            <p className="text-lg font-semibold text-gray-700">Interactive Map</p>
            <p className="text-sm text-gray-500">Real-time GPS tracking for all ambulances</p>
          </div>
          
          {/* Simulated ambulance markers */}
          {ambulances.slice(0, 2).map((amb, index) => (
            <div
              key={amb.id}
              className={`absolute w-4 h-4 bg-red-500 rounded-full border-2 border-white shadow-lg animate-pulse`}
              style={{
                left: `${20 + index * 30}%`,
                top: `${30 + index * 20}%`
              }}
            />
          ))}
        </div>
      </div>

      {/* Ambulance List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {ambulances.map((ambulance) => (
          <div 
            key={ambulance.id} 
            className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-all duration-200"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Truck className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{ambulance.id}</h3>
                  <p className="text-sm text-gray-500">{ambulance.driverName}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {ambulance.verified ? (
                  <CheckCircle className="w-5 h-5 text-green-600" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-orange-500" />
                )}
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(ambulance.status)}`}>
                  {ambulance.status.replace('-', ' ')}
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 text-gray-500 mt-0.5" />
                <span className="text-sm text-gray-600">{ambulance.location.address}</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600">ETA: {ambulance.eta}</span>
              </div>

              {ambulance.patientId && (
                <div className="flex items-center space-x-2">
                  <User className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-600">Patient: {ambulance.patientId}</span>
                  <span className={`text-xs font-medium ${getPriorityColor(ambulance.priority)}`}>
                    ({ambulance.priority})
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center space-x-2 mt-4 pt-4 border-t border-gray-100">
              <button 
                className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                onClick={() => setSelectedAmbulance(ambulance.id)}
              >
                <Navigation className="w-4 h-4" />
                <span>Track</span>
              </button>
              <button className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                <Phone className="w-4 h-4" />
                <span>Call</span>
              </button>
              {!ambulance.verified && (
                <button 
                  className="flex items-center justify-center p-2 text-sm bg-orange-100 text-orange-600 rounded-lg hover:bg-orange-200 transition-colors"
                  onClick={() => setShowVerificationModal(true)}
                >
                  <Camera className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Driver Verification Modal */}
      {showVerificationModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-lg max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Driver Face Verification</h3>
            <div className="bg-gray-100 h-48 rounded-lg flex items-center justify-center mb-4">
              <div className="text-center">
                <Camera className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Camera preview would appear here</p>
                <p className="text-xs text-gray-500">Using TensorFlow + FaceAPI.js</p>
              </div>
            </div>
            <div className="flex space-x-3">
              <button
                onClick={() => setShowVerificationModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleVerifyDriver('AMB-003')}
                className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Verify
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AmbulanceTracker;