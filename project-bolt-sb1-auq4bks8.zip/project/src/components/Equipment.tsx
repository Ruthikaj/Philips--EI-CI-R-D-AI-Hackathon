import React, { useState, useEffect } from 'react';
import { 
  Wrench, 
  Camera, 
  Upload,
  AlertTriangle,
  CheckCircle,
  Clock,
  Activity,
  QrCode,
  Zap,
  Heart,
  Wind,
  Monitor
} from 'lucide-react';

interface EquipmentItem {
  id: string;
  name: string;
  type: 'ventilator' | 'oxygen' | 'monitor' | 'defibrillator';
  status: 'operational' | 'maintenance' | 'faulty' | 'offline';
  location: string;
  lastService: string;
  nextService: string;
  usageHours: number;
  batteryLevel?: number;
  alerts: string[];
}

const Equipment: React.FC = () => {
  const [equipment, setEquipment] = useState<EquipmentItem[]>([
    {
      id: 'VNT-001',
      name: 'Ventilator Unit A1',
      type: 'ventilator',
      status: 'operational',
      location: 'ICU - Room 201',
      lastService: '2024-01-10',
      nextService: '2024-02-10',
      usageHours: 1250,
      batteryLevel: 98,
      alerts: []
    },
    {
      id: 'OXY-002',
      name: 'Oxygen Concentrator B2',
      type: 'oxygen',
      status: 'maintenance',
      location: 'Ward - Room 305',
      lastService: '2024-01-05',
      nextService: '2024-01-20',
      usageHours: 2100,
      alerts: ['Filter replacement due', 'Pressure adjustment needed']
    },
    {
      id: 'MON-003',
      name: 'Patient Monitor C3',
      type: 'monitor',
      status: 'faulty',
      location: 'Emergency - Bay 4',
      lastService: '2023-12-15',
      nextService: '2024-01-18',
      usageHours: 3200,
      batteryLevel: 45,
      alerts: ['Display flickering', 'Calibration required']
    }
  ]);

  const [selectedEquipment, setSelectedEquipment] = useState<EquipmentItem | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setEquipment(prev => prev.map(item => ({
        ...item,
        usageHours: item.usageHours + Math.floor(Math.random() * 2),
        batteryLevel: item.batteryLevel ? Math.max(20, item.batteryLevel - Math.floor(Math.random() * 2)) : undefined
      })));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational': return 'bg-green-100 text-green-700';
      case 'maintenance': return 'bg-yellow-100 text-yellow-700';
      case 'faulty': return 'bg-red-100 text-red-700';
      case 'offline': return 'bg-gray-100 text-gray-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'ventilator': return Wind;
      case 'oxygen': return Activity;
      case 'monitor': return Monitor;
      case 'defibrillator': return Heart;
      default: return Wrench;
    }
  };

  const handleImageUpload = (equipmentId: string) => {
    // Simulate AI damage detection
    setTimeout(() => {
      const randomAnalysis = Math.random();
      let condition, recommendation;
      
      if (randomAnalysis > 0.7) {
        condition = 'Critical damage detected';
        recommendation = 'Immediate replacement required';
      } else if (randomAnalysis > 0.4) {
        condition = 'Minor wear detected';
        recommendation = 'Schedule maintenance within 7 days';
      } else {
        condition = 'Equipment appears functional';
        recommendation = 'Continue regular monitoring';
      }

      setEquipment(prev => prev.map(item => 
        item.id === equipmentId 
          ? { 
              ...item, 
              alerts: [...item.alerts, `AI Analysis: ${condition}`],
              status: randomAnalysis > 0.7 ? 'faulty' : item.status
            }
          : item
      ));
      
      alert(`🤖 AI Analysis Complete!\n\n${condition}\n\nRecommendation: ${recommendation}`);
      setShowUploadModal(false);
    }, 2000);
  };

  const getMaintenanceUrgency = (nextService: string) => {
    const today = new Date();
    const serviceDate = new Date(nextService);
    const daysUntil = Math.ceil((serviceDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntil <= 3) return { color: 'text-red-600', label: 'Urgent' };
    if (daysUntil <= 7) return { color: 'text-yellow-600', label: 'Due Soon' };
    return { color: 'text-green-600', label: 'On Schedule' };
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-orange-100 rounded-lg">
              <Wrench className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Equipment Management</h2>
              <p className="text-sm text-gray-500">AI-powered monitoring and maintenance</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button 
              className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              onClick={() => setShowQRModal(true)}
            >
              <QrCode className="w-4 h-4" />
              <span>QR Scan</span>
            </button>
            <button 
              className="flex items-center space-x-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
              onClick={() => setShowUploadModal(true)}
            >
              <Camera className="w-4 h-4" />
              <span>AI Damage Check</span>
            </button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">
              {equipment.filter(e => e.status === 'operational').length}
            </div>
            <div className="text-sm text-green-700">Operational</div>
          </div>
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600">
              {equipment.filter(e => e.status === 'maintenance').length}
            </div>
            <div className="text-sm text-yellow-700">Maintenance</div>
          </div>
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <div className="text-2xl font-bold text-red-600">
              {equipment.filter(e => e.status === 'faulty').length}
            </div>
            <div className="text-sm text-red-700">Faulty</div>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">87%</div>
            <div className="text-sm text-blue-700">Efficiency</div>
          </div>
        </div>
      </div>

      {/* Equipment List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {equipment.map((item) => {
          const Icon = getTypeIcon(item.type);
          const maintenanceUrgency = getMaintenanceUrgency(item.nextService);
          
          return (
            <div 
              key={item.id}
              className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-all duration-200 cursor-pointer"
              onClick={() => setSelectedEquipment(item)}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-gray-100 rounded-lg">
                    <Icon className="w-5 h-5 text-gray-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{item.name}</h3>
                    <p className="text-sm text-gray-500">{item.id}</p>
                  </div>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item.status)}`}>
                  {item.status}
                </span>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Location</span>
                  <span className="text-gray-900">{item.location}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Usage Hours</span>
                  <span className="text-gray-900">{item.usageHours.toLocaleString()}h</span>
                </div>
                {item.batteryLevel !== undefined && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Battery</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-gray-200 rounded-full">
                        <div 
                          className={`h-full rounded-full ${
                            item.batteryLevel > 50 ? 'bg-green-500' :
                            item.batteryLevel > 20 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${item.batteryLevel}%` }}
                        />
                      </div>
                      <span className="text-gray-900">{item.batteryLevel}%</span>
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Next Service</span>
                  <span className={maintenanceUrgency.color}>
                    {item.nextService} ({maintenanceUrgency.label})
                  </span>
                </div>
              </div>

              {item.alerts.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <div className="flex items-start space-x-2">
                    <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-red-900 mb-1">Alerts</p>
                      {item.alerts.map((alert, index) => (
                        <p key={index} className="text-xs text-red-700">{alert}</p>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              <div className="flex items-center space-x-2 mt-4 pt-4 border-t border-gray-100">
                <button className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                  <Activity className="w-4 h-4" />
                  <span>Monitor</span>
                </button>
                <button 
                  className="flex items-center justify-center p-2 text-sm bg-orange-100 text-orange-600 rounded-lg hover:bg-orange-200 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowUploadModal(true);
                  }}
                >
                  <Camera className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* AI Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-lg max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">AI Damage Assessment</h3>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center mb-4">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-sm text-gray-600 mb-2">
                Upload equipment photo for AI analysis
              </p>
              <p className="text-xs text-gray-500">
                AI will detect damage, wear, and maintenance needs
              </p>
            </div>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
              <div className="flex items-start space-x-2">
                <Zap className="w-4 h-4 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-blue-900">AI Features</p>
                  <ul className="text-xs text-blue-700 mt-1 space-y-1">
                    <li>• Visual damage detection</li>
                    <li>• Wear pattern analysis</li>
                    <li>• Maintenance recommendations</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="flex space-x-3">
              <button
                onClick={() => setShowUploadModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleImageUpload('VNT-001')}
                className="flex-1 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
              >
                Analyze
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QR Scanner Modal */}
      {showQRModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-lg max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">QR Code Scanner</h3>
            <div className="bg-gray-100 h-48 rounded-lg flex items-center justify-center mb-4">
              <div className="text-center">
                <QrCode className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Camera scanner would appear here</p>
                <p className="text-xs text-gray-500">Scan equipment QR for instant details</p>
              </div>
            </div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
              <p className="text-sm font-medium text-green-900 mb-1">Quick Access</p>
              <p className="text-xs text-green-700">
                Instantly fetch model info, service history, and stock levels
              </p>
            </div>
            <div className="flex space-x-3">
              <button
                onClick={() => setShowQRModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Start Scan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Equipment;