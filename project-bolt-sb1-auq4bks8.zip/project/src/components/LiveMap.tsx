import React, { useState, useEffect } from 'react';
import { 
  Map, 
  MapPin, 
  Navigation, 
  Star,
  Clock,
  Bed,
  Phone,
  Filter,
  Search,
  Truck,
  Activity
} from 'lucide-react';

interface Hospital {
  id: string;
  name: string;
  location: { lat: number; lng: number; address: string };
  beds: { total: number; available: number };
  icu: { total: number; available: number };
  rating: number;
  waitTime: number;
  distance: number;
  specialties: string[];
  equipment: { ventilators: number; monitors: number };
}

interface Ambulance {
  id: string;
  location: { lat: number; lng: number };
  status: 'idle' | 'en-route' | 'busy';
  eta?: number;
}

const LiveMap: React.FC = () => {
  const [hospitals] = useState<Hospital[]>([
    {
      id: 'H001',
      name: 'City General Hospital',
      location: { lat: 40.7128, lng: -74.0060, address: '123 Main St, NYC' },
      beds: { total: 200, available: 45 },
      icu: { total: 50, available: 12 },
      rating: 4.2,
      waitTime: 25,
      distance: 1.2,
      specialties: ['Emergency', 'Cardiology', 'Neurology'],
      equipment: { ventilators: 15, monitors: 40 }
    },
    {
      id: 'H002',
      name: 'Metro Medical Center',
      location: { lat: 40.7589, lng: -73.9851, address: '456 Broadway, NYC' },
      beds: { total: 150, available: 23 },
      icu: { total: 30, available: 8 },
      rating: 4.5,
      waitTime: 18,
      distance: 2.8,
      specialties: ['Emergency', 'Orthopedics', 'Pediatrics'],
      equipment: { ventilators: 12, monitors: 25 }
    },
    {
      id: 'H003',
      name: 'Central Healthcare',
      location: { lat: 40.7831, lng: -73.9712, address: '789 Central Ave, NYC' },
      beds: { total: 300, available: 67 },
      icu: { total: 60, available: 18 },
      rating: 4.7,
      waitTime: 12,
      distance: 3.5,
      specialties: ['Emergency', 'Surgery', 'Oncology'],
      equipment: { ventilators: 20, monitors: 55 }
    }
  ]);

  const [ambulances, setAmbulances] = useState<Ambulance[]>([
    { id: 'AMB-001', location: { lat: 40.7200, lng: -74.0100 }, status: 'en-route', eta: 8 },
    { id: 'AMB-002', location: { lat: 40.7500, lng: -73.9800 }, status: 'idle' },
    { id: 'AMB-003', location: { lat: 40.7750, lng: -73.9650 }, status: 'busy' }
  ]);

  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);
  const [filters, setFilters] = useState({
    icuAvailable: false,
    waitTimeLess30: false,
    ratingAbove4: false
  });
  const [searchQuery, setSearchQuery] = useState('');

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setAmbulances(prev => prev.map(amb => ({
        ...amb,
        location: {
          lat: amb.location.lat + (Math.random() - 0.5) * 0.002,
          lng: amb.location.lng + (Math.random() - 0.5) * 0.002
        }
      })));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const filteredHospitals = hospitals.filter(hospital => {
    if (searchQuery && !hospital.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    if (filters.icuAvailable && hospital.icu.available === 0) return false;
    if (filters.waitTimeLess30 && hospital.waitTime >= 30) return false;
    if (filters.ratingAbove4 && hospital.rating <= 4.0) return false;
    return true;
  });

  const handleBookBed = (hospitalId: string) => {
    alert(`🏥 Bed Booking Request\n\nHospital: ${hospitals.find(h => h.id === hospitalId)?.name}\n\nBooking initiated...\nConfirmation will be sent via SMS and email.`);
  };

  const handleRateHospital = (hospitalId: string) => {
    alert(`⭐ Rate Hospital\n\nThank you for your feedback!\nYour rating helps improve our services.\n\nRating submitted successfully.`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-indigo-100 rounded-lg">
              <Map className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Live Healthcare Map</h2>
              <p className="text-sm text-gray-500">Real-time hospital and ambulance tracking within 10km</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-gray-600">Live sync active</span>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search hospitals by name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
            />
          </div>
          <div className="flex items-center space-x-2">
            <label className="flex items-center space-x-2 text-sm text-gray-700">
              <input
                type="checkbox"
                checked={filters.icuAvailable}
                onChange={(e) => setFilters(prev => ({ ...prev, icuAvailable: e.target.checked }))}
                className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
              />
              <span>ICU Available</span>
            </label>
            <label className="flex items-center space-x-2 text-sm text-gray-700">
              <input
                type="checkbox"
                checked={filters.waitTimeLess30}
                onChange={(e) => setFilters(prev => ({ ...prev, waitTimeLess30: e.target.checked }))}
                className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
              />
              <span>Wait &lt; 30min</span>
            </label>
            <label className="flex items-center space-x-2 text-sm text-gray-700">
              <input
                type="checkbox"
                checked={filters.ratingAbove4}
                onChange={(e) => setFilters(prev => ({ ...prev, ratingAbove4: e.target.checked }))}
                className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
              />
              <span>Rating ≥ 4.0</span>
            </label>
          </div>
        </div>
      </div>

      {/* Map View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Map */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="bg-gradient-to-br from-indigo-50 to-blue-50 h-96 rounded-lg relative overflow-hidden">
            {/* Map background */}
            <div className="absolute inset-0 opacity-20">
              <svg className="w-full h-full" viewBox="0 0 400 300">
                <defs>
                  <pattern id="mapGrid" width="30" height="30" patternUnits="userSpaceOnUse">
                    <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#3b82f6" strokeWidth="0.5"/>
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#mapGrid)" />
              </svg>
            </div>

            {/* Hospital Markers */}
            {filteredHospitals.map((hospital, index) => (
              <div
                key={hospital.id}
                className={`absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2 ${
                  selectedHospital?.id === hospital.id ? 'z-20' : 'z-10'
                }`}
                style={{
                  left: `${20 + index * 25}%`,
                  top: `${30 + index * 15}%`
                }}
                onClick={() => setSelectedHospital(hospital)}
              >
                <div className={`w-8 h-8 rounded-full border-3 border-white shadow-lg flex items-center justify-center ${
                  hospital.icu.available > 0 ? 'bg-green-500' :
                  hospital.beds.available > 0 ? 'bg-yellow-500' : 'bg-red-500'
                }`}>
                  <MapPin className="w-4 h-4 text-white" />
                </div>
                {selectedHospital?.id === hospital.id && (
                  <div className="absolute top-10 left-1/2 transform -translate-x-1/2 bg-white rounded-lg shadow-lg p-4 min-w-64 z-30">
                    <div className="space-y-3">
                      <div>
                        <h4 className="font-semibold text-gray-900">{hospital.name}</h4>
                        <p className="text-sm text-gray-500">{hospital.location.address}</p>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <div className="flex items-center space-x-1">
                            <Bed className="w-4 h-4 text-blue-600" />
                            <span>Beds: {hospital.beds.available}/{hospital.beds.total}</span>
                          </div>
                          <div className="flex items-center space-x-1 mt-1">
                            <Activity className="w-4 h-4 text-red-600" />
                            <span>ICU: {hospital.icu.available}/{hospital.icu.total}</span>
                          </div>
                        </div>
                        <div>
                          <div className="flex items-center space-x-1">
                            <Star className="w-4 h-4 text-yellow-500" />
                            <span>{hospital.rating}/5.0</span>
                          </div>
                          <div className="flex items-center space-x-1 mt-1">
                            <Clock className="w-4 h-4 text-gray-500" />
                            <span>{hospital.waitTime} min wait</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 pt-2 border-t border-gray-200">
                        <button
                          onClick={() => handleBookBed(hospital.id)}
                          className="flex-1 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                        >
                          Book Bed
                        </button>
                        <button
                          onClick={() => handleRateHospital(hospital.id)}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm"
                        >
                          Rate Hospital
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {/* Ambulance Markers */}
            {ambulances.map((ambulance, index) => (
              <div
                key={ambulance.id}
                className="absolute transform -translate-x-1/2 -translate-y-1/2"
                style={{
                  left: `${60 + index * 15}%`,
                  top: `${20 + index * 20}%`
                }}
              >
                <div className={`w-6 h-6 rounded-full border-2 border-white shadow-lg flex items-center justify-center ${
                  ambulance.status === 'idle' ? 'bg-blue-500' :
                  ambulance.status === 'en-route' ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                }`}>
                  <Truck className="w-3 h-3 text-white" />
                </div>
                {ambulance.eta && (
                  <div className="absolute top-8 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-75 text-white px-2 py-1 rounded text-xs whitespace-nowrap">
                    ETA: {ambulance.eta}m
                  </div>
                )}
              </div>
            ))}

            {/* Legend */}
            <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-3">
              <div className="text-sm font-medium text-gray-900 mb-2">Legend</div>
              <div className="space-y-1 text-xs">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span>ICU Available</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <span>Beds Available</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span>Full Capacity</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Truck className="w-3 h-3 text-blue-500" />
                  <span>Ambulance</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Hospital List */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-6 border-b border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900">Nearby Hospitals</h3>
            <p className="text-sm text-gray-500">{filteredHospitals.length} hospitals found</p>
          </div>
          <div className="p-6">
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {filteredHospitals.map((hospital) => (
                <div
                  key={hospital.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-all duration-200 hover:shadow-md ${
                    selectedHospital?.id === hospital.id ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200'
                  }`}
                  onClick={() => setSelectedHospital(hospital)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-semibold text-gray-900">{hospital.name}</h4>
                      <p className="text-sm text-gray-500">{hospital.distance}km away</p>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span className="text-sm font-medium">{hospital.rating}</span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 mb-3 text-sm">
                    <div className="flex items-center space-x-2">
                      <Bed className="w-4 h-4 text-blue-600" />
                      <span>Beds: {hospital.beds.available}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Activity className="w-4 h-4 text-red-600" />
                      <span>ICU: {hospital.icu.available}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span>{hospital.waitTime} min</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Navigation className="w-4 h-4 text-green-600" />
                      <span>Navigate</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-3">
                    {hospital.specialties.slice(0, 3).map((specialty, index) => (
                      <span key={index} className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-xs">
                        {specialty}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleBookBed(hospital.id);
                      }}
                      className="flex-1 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                    >
                      Book Bed
                    </button>
                    <button className="flex items-center justify-center p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                      <Phone className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveMap;