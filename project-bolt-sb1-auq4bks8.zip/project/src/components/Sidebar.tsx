import React from 'react';
import { 
  LayoutDashboard, 
  Truck, 
  Users, 
  Brain, 
  Wrench, 
  BarChart3, 
  AlertTriangle, 
  MessageSquare, 
  Map,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface SidebarProps {
  activeModule: string;
  setActiveModule: (module: string) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

const modules = [
  { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard },
  { id: 'ambulance', name: 'Ambulance Tracker', icon: Truck },
  { id: 'patients', name: 'Patient Management', icon: Users },
  { id: 'triage', name: 'AI Triage', icon: Brain },
  { id: 'equipment', name: 'Equipment', icon: Wrench },
  { id: 'analytics', name: 'Analytics', icon: BarChart3 },
  { id: 'emergencies', name: 'Emergencies', icon: AlertTriangle },
  { id: 'assistant', name: 'AI Assistant', icon: MessageSquare },
  { id: 'map', name: 'Live Map', icon: Map },
];

const Sidebar: React.FC<SidebarProps> = ({ 
  activeModule, 
  setActiveModule, 
  collapsed, 
  setCollapsed 
}) => {
  return (
    <div className={`fixed left-0 top-0 h-full bg-white shadow-lg transition-all duration-300 z-40 ${
      collapsed ? 'w-16' : 'w-64'
    }`}>
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">N</span>
            </div>
            <span className="font-bold text-gray-900">NextPulse</span>
          </div>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-1 rounded-md hover:bg-gray-100 transition-colors"
        >
          {collapsed ? (
            <ChevronRight className="w-5 h-5 text-gray-600" />
          ) : (
            <ChevronLeft className="w-5 h-5 text-gray-600" />
          )}
        </button>
      </div>
      
      <nav className="mt-4 px-2">
        {modules.map((module) => {
          const Icon = module.icon;
          const isActive = activeModule === module.id;
          
          return (
            <button
              key={module.id}
              onClick={() => setActiveModule(module.id)}
              className={`w-full flex items-center px-3 py-3 mb-1 rounded-lg transition-all duration-200 group ${
                isActive 
                  ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-600' 
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <Icon className={`w-5 h-5 ${collapsed ? 'mx-auto' : 'mr-3'} ${
                isActive ? 'text-blue-600' : 'text-gray-500'
              }`} />
              {!collapsed && (
                <span className="font-medium text-sm">{module.name}</span>
              )}
              {collapsed && (
                <div className="absolute left-16 bg-gray-900 text-white px-2 py-1 rounded text-sm opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 whitespace-nowrap z-50">
                  {module.name}
                </div>
              )}
            </button>
          );
        })}
      </nav>
      
      <div className="absolute bottom-4 left-0 right-0 px-4">
        <div className={`text-center ${collapsed ? 'px-2' : 'px-4'}`}>
          <div className="w-full h-1 bg-green-200 rounded-full mb-2">
            <div className="h-full bg-green-500 rounded-full" style={{ width: '87%' }}></div>
          </div>
          {!collapsed && (
            <p className="text-xs text-gray-500">System Health: 87%</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;