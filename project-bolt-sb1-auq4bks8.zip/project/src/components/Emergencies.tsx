import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  Phone, 
  Clock, 
  User, 
  MapPin, 
  Check,
  X,
  Zap,
  Heart,
  Truck
} from 'lucide-react';

interface Emergency {
  id: string;
  patientName: string;
  patientId: string;
  priority: 'critical' | 'high' | 'medium';
  condition: string;
  location: string;
  reportedTime: string;
  status: 'active' | 'responded' | 'resolved';
  responder?: string;
  responseTime?: string;
  description: string;
}

const Emergencies: React.FC = () => {
  const [emergencies, setEmergencies] = useState<Emergency[]>([
    {
      id: 'EMG-001',
      patientName: 'John Anderson',
      patientId: 'P-2024-045',
      priority: 'critical',
      condition: 'Cardiac Arrest',
      location: 'Emergency - Bay 3',
      reportedTime: '14:23:15',
      status: 'active',
      description: 'Patient collapsed, no pulse, CPR initiated'
    },
    {
      id: 'EMG-002',
      patientName: 'Maria Santos',
      patientId: 'P-2024-046',
      priority: 'high',
      condition: 'Severe Allergic Reaction',
      location: 'Ward - Room 205',
      reportedTime: '14:18:42',
      status: 'responded',
      responder: 'Dr. Sarah Chen',
      responseTime: '2 minutes',
      description: 'Anaphylactic reaction to medication, breathing difficulty'
    },
    {
      id: 'EMG-003',
      patientName: 'David Kim',
      patientId: 'P-2024-047',
      priority: 'medium',
      condition: 'Fall with Head Injury',
      location: 'ICU - Room 102',
      reportedTime: '13:45:20',
      status: 'resolved',
      responder: 'Dr. Michael Rodriguez',
      responseTime: '4 minutes',
      description: 'Patient fell in bathroom, conscious but dizzy'
    }
  ]);

  const [autoCallEnabled, setAutoCallEnabled] = useState(true);
  const [selectedEmergency, setSelectedEmergency] = useState<Emergency | null>(null);

  // Simulate real-time emergency updates
  useEffect(() => {
    const interval = setInterval(() => {
      setEmergencies(prev => prev.map(emergency => ({
        ...emergency,
        reportedTime: emergency.status === 'active' ? 
          new Date().toLocaleTimeString() : 
          emergency.reportedTime
      })));
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-500 text-white';
      case 'high': return 'bg-orange-500 text-white';
      case 'medium': return 'bg-yellow-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-red-600 bg-red-50 border-red-200';
      case 'responded': return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'resolved': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const handleRespond = (emergencyId: string) => {
    setEmergencies(prev => prev.map(emergency => 
      emergency.id === emergencyId 
        ? { 
            ...emergency, 
            status: 'responded' as const, 
            responder: 'Dr. Sarah Chen',
            responseTime: '1 minute'
          }
        : emergency
    ));
    
    // Simulate automatic call if enabled
    if (autoCallEnabled) {
      setTimeout(() => {
        alert(`📞 Auto-call initiated to emergency staff\n\nEmergency: ${emergencyId}\nEstimated arrival: 2 minutes`);
      }, 1000);
    }
  };

  const handleResolve = (emergencyId: string) => {
    setEmergencies(prev => prev.map(emergency => 
      emergency.id === emergencyId 
        ? { ...emergency, status: 'resolved' as const }
        : emergency
    ));
  };

  const handleEscalate = (emergencyId: string) => {
    alert(`🚨 Emergency escalated!\n\nBackup doctor notified\nMobile push notification sent\nEmail alert dispatched\n\nEmergency ID: ${emergencyId}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-red-100 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Emergency Management</h2>
              <p className="text-sm text-gray-500">Real-time emergency response system</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="autoCall"
                checked={autoCallEnabled}
                onChange={(e) => setAutoCallEnabled(e.target.checked)}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <label htmlFor="autoCall" className="text-sm text-gray-700">
                Auto-call staff
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-600">
                {emergencies.filter(e => e.status === 'active').length} Active
              </span>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-3 bg-red-50 rounded-lg">
            <div className="text-2xl font-bold text-red-600">
              {emergencies.filter(e => e.priority === 'critical').length}
            </div>
            <div className="text-sm text-red-700">Critical</div>
          </div>
          <div className="text-center p-3 bg-orange-50 rounded-lg">
            <div className="text-2xl font-bold text-orange-600">
              {emergencies.filter(e => e.priority === 'high').length}
            </div>
            <div className="text-sm text-orange-700">High Priority</div>
          </div>
          <div className="text-center p-3 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">
              {emergencies.filter(e => e.status === 'responded').length}
            </div>
            <div className="text-sm text-blue-700">Responded</div>
          </div>
          <div className="text-center p-3 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">
              {emergencies.filter(e => e.status === 'resolved').length}
            </div>
            <div className="text-sm text-green-700">Resolved</div>
          </div>
        </div>
      </div>

      {/* Emergency Feed */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-900">Live Emergency Feed</h3>
        {emergencies.map((emergency) => (
          <div 
            key={emergency.id}
            className={`bg-white rounded-xl shadow-sm border-l-4 p-6 ${
              emergency.priority === 'critical' ? 'border-l-red-500' :
              emergency.priority === 'high' ? 'border-l-orange-500' : 'border-l-yellow-500'
            } hover:shadow-md transition-all duration-200`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${getPriorityColor(emergency.priority)}`}>
                    {emergency.priority.toUpperCase()}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(emergency.status)}`}>
                    {emergency.status.replace('-', ' ')}
                  </span>
                </div>
                {emergency.status === 'active' && (
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-ping"></div>
                    <span className="text-xs text-red-600 font-medium">URGENT RESPONSE NEEDED</span>
                  </div>
                )}
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{emergency.id}</p>
                <div className="flex items-center space-x-1 text-xs text-gray-500">
                  <Clock className="w-3 h-3" />
                  <span>{emergency.reportedTime}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <User className="w-4 h-4 text-gray-500" />
                  <span className="font-medium text-gray-900">{emergency.patientName}</span>
                  <span className="text-sm text-gray-500">({emergency.patientId})</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Heart className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-900">{emergency.condition}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-900">{emergency.location}</span>
                </div>
                <p className="text-sm text-gray-600 bg-gray-50 rounded-lg p-3">
                  {emergency.description}
                </p>
              </div>

              <div className="space-y-4">
                {emergency.status === 'responded' && emergency.responder && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-blue-900">Responder Assigned</p>
                        <p className="text-sm text-blue-700">{emergency.responder}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-blue-600">Response Time</p>
                        <p className="text-sm font-bold text-blue-900">{emergency.responseTime}</p>
                      </div>
                    </div>
                  </div>
                )}

                {emergency.status === 'resolved' && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2">
                      <Check className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-green-900">Emergency Resolved</span>
                    </div>
                    <p className="text-xs text-green-700 mt-1">
                      Handled by {emergency.responder} in {emergency.responseTime}
                    </p>
                  </div>
                )}

                <div className="flex items-center space-x-2">
                  {emergency.status === 'active' && (
                    <>
                      <button
                        onClick={() => handleRespond(emergency.id)}
                        className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        <Check className="w-4 h-4" />
                        <span>Respond</span>
                      </button>
                      <button
                        onClick={() => handleEscalate(emergency.id)}
                        className="flex items-center justify-center space-x-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                      >
                        <Zap className="w-4 h-4" />
                        <span>Escalate</span>
                      </button>
                    </>
                  )}
                  
                  {emergency.status === 'responded' && (
                    <button
                      onClick={() => handleResolve(emergency.id)}
                      className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                    >
                      <Check className="w-4 h-4" />
                      <span>Mark Resolved</span>
                    </button>
                  )}
                  
                  <button className="flex items-center justify-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                    <Phone className="w-4 h-4" />
                    <span>Call</span>
                  </button>
                  
                  {emergency.priority === 'critical' && (
                    <button className="flex items-center justify-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                      <Truck className="w-4 h-4" />
                      <span>Ambulance</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Emergency Protocol Panel */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Emergency Protocol Status</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <h4 className="font-semibold text-red-900">Critical Response</h4>
            </div>
            <p className="text-sm text-red-700 mb-2">
              Auto-dispatch activated for critical emergencies
            </p>
            <div className="text-xs text-red-600">
              ✓ Staff notification: Instant
              <br />
              ✓ Backup team: 3-minute alert
              <br />
              ✓ Equipment prep: Automatic
            </div>
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Phone className="w-5 h-5 text-blue-600" />
              <h4 className="font-semibold text-blue-900">Communication</h4>
            </div>
            <p className="text-sm text-blue-700 mb-2">
              Multi-channel alert system active
            </p>
            <div className="text-xs text-blue-600">
              ✓ Twilio voice calls
              <br />
              ✓ Push notifications
              <br />
              ✓ Email alerts
            </div>
          </div>
          
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Check className="w-5 h-5 text-green-600" />
              <h4 className="font-semibold text-green-900">Response Tracking</h4>
            </div>
            <p className="text-sm text-green-700 mb-2">
              Real-time response monitoring
            </p>
            <div className="text-xs text-green-600">
              ✓ Timestamp logging
              <br />
              ✓ Performance analytics
              <br />
              ✓ Audit trail complete
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Emergencies;